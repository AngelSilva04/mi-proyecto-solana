import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";

describe("contador", () => {

  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.contador as Program;

  it("Incrementar contador", async () => {

    const cuenta = anchor.web3.Keypair.generate();

    // Inicializar contador
    await program.methods.initialize()
      .accounts({
        contador: cuenta.publicKey,
        usuario: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([cuenta])
      .rpc();

    // Incrementar contador
    await program.methods.incrementar()
      .accounts({
        contador: cuenta.publicKey,
      })
      .rpc();

    // Leer contador
    const data = await program.account.contador.fetch(cuenta.publicKey);

    console.log("Valor del contador:", data.valor);

  });

});