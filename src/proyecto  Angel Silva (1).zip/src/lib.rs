use anchor_lang::prelude::*;

declare_id!("TU_PROGRAM_ID");

#[program]
pub mod contador {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let cuenta = &mut ctx.accounts.contador;
        cuenta.valor = 0;
        Ok(())
    }

    pub fn incrementar(ctx: Context<Incrementar>) -> Result<()> {
        let cuenta = &mut ctx.accounts.contador;
        cuenta.valor += 1;
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(init, payer = usuario, space = 8 + 8)]
    pub contador: Account<'info, Contador>,

    #[account(mut)]
    pub usuario: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Incrementar<'info> {
    #[account(mut)]
    pub contador: Account<'info, Contador>,
}

#[account]
pub struct Contador {
    pub valor: u64,
}